package com.seasonal.layer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RadialGradient
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface as DisplaySurface
import android.view.View
import android.view.WindowManager
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Прозрачный слой поверх всего экрана: снег с физикой, сугробы на иконках,
 * постепенное «заметание» экрана и гирлянда сверху.
 */
class SnowOverlayView(ctx: Context, private val cfg: Cfg) : View(ctx), SensorEventListener {

    private class Flake(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        val r: Float, val phase: Float, var life: Float = -1f
    )

    private class Surf(var l: Float, var t: Float, var r: Float, val cap: Float, var h: FloatArray) {
        var goal: FloatArray? = null
    }

    private val d = resources.displayMetrics.density
    private val step = 5f * d

    private val flakes = ArrayList<Flake>()
    private var nodeSurfs: List<Surf> = emptyList()
    private var ground: Surf? = null
    private var all: List<Surf> = emptyList()

    // настройки (кэш)
    private var palette = 0
    private var mode = 0
    private var garlandOn = true
    private var winterOnly = false
    private var force = false
    private var knockThreshold = 7f

    // состояние погоды
    private var snowing = false
    private var intensity = 0.6f
    private var lastDayCheck = -100f
    private var cover = 0f
    private var coverGoal = -1f
    private var time = 0f
    private var last = 0L
    private var normalCount = 0

    // датчики
    private var gx = 0f
    private var lp = 9.81f
    private var spikes = 0
    private var firstSpikeQuiet = false
    private var lastSpike = 0L
    private var firstSpike = 0L
    private var shakeT = 0f

    private val topInset: Float = run {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (id > 0) resources.getDimensionPixelSize(id).toFloat() else 24f * d
    }

    private val flakePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val snowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF4F8FF.toInt() }
    private val frostPaint = Paint()
    private val whitePaint = Paint().apply { color = 0xFFFFFFFF.toInt() }
    private val wirePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF10281A.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f * d
    }
    private val bulbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val wire = Path()

    init { reloadCfg() }

    fun reloadCfg() {
        palette = cfg.palette.coerceIn(0, PALETTES.size - 1)
        mode = cfg.mode.coerceIn(0, MODES - 1)
        garlandOn = cfg.garlandOn
        winterOnly = cfg.winterOnly
        force = cfg.forceSnow
        knockThreshold = floatArrayOf(9f, 7f, 5f)[cfg.sens.coerceIn(0, 2)]
        lastDayCheck = -100f
    }

    fun nextPalette() { cfg.palette = (palette + 1) % PALETTES.size; palette = cfg.palette }
    fun nextMode() { cfg.mode = (mode + 1) % MODES; mode = cfg.mode }

    // ---------- окружение ----------

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        postInvalidateOnAnimation()
    }

    override fun onDetachedFromWindow() {
        (context.getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(this)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cols = ceil(w / step).toInt() + 1
        ground = Surf(0f, h.toFloat(), w.toFloat(), 28f * d, FloatArray(cols))
        rebuildAll()
        frostPaint.shader = RadialGradient(
            w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) / 2f,
            intArrayOf(0x00FFFFFF, 0x00FFFFFF, 0xFFFFFFFF.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun rebuildAll() { all = nodeSurfs + listOfNotNull(ground) }

    override fun onSensorChanged(e: SensorEvent) {
        val ax = e.values[0]; val ay = e.values[1]; val az = e.values[2]
        val rot = (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
        val sx = when (rot) {
            DisplaySurface.ROTATION_90 -> ay
            DisplaySurface.ROTATION_180 -> ax
            DisplaySurface.ROTATION_270 -> -ay
            else -> -ax
        }
        gx += ((sx / 9.81f).coerceIn(-1f, 1f) - gx) * 0.15f

        val mag = sqrt(ax * ax + ay * ay + az * az)
        lp = lp * 0.92f + mag * 0.08f
        if (abs(mag - lp) > knockThreshold) {
            val now = System.nanoTime() / 1_000_000
            if (now - lastSpike > 60) {
                if (spikes == 0) { firstSpikeQuiet = now - lastSpike > 700; firstSpike = now }
                spikes++
                lastSpike = now
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // ---------- поверхности из доступности ----------

    /** Новый список прямоугольников (иконки, кнопки) — вызывается службой. */
    fun setRects(rs: List<Rect>) {
        val old = ArrayList(nodeSurfs)
        val next = ArrayList<Surf>()
        val tol = 8f * d
        for (r in rs) {
            val m = old.firstOrNull {
                abs(it.l - r.left) < tol && abs(it.t - r.top) < tol && abs(it.r - r.right) < tol
            }
            if (m != null) {
                old.remove(m)
                m.l = r.left.toFloat(); m.t = r.top.toFloat(); m.r = r.right.toFloat()
                next.add(m)
            } else {
                val cols = ceil(r.width() / step).toInt() + 1
                next.add(Surf(r.left.toFloat(), r.top.toFloat(), r.right.toFloat(), 12f * d, FloatArray(cols)))
            }
        }
        old.forEach { shed(it) }   // иконку сдвинули или она исчезла — снег с неё падает
        nodeSurfs = next
        rebuildAll()
    }

    private fun shed(s: Surf) {
        for (c in s.h.indices) {
            if (s.h[c] < d) continue
            repeat((s.h[c] / (2.4f * d)).toInt() + 1) {
                if (flakes.size < 1100) flakes.add(
                    Flake(s.l + c * step + rnd(-2f, 2f) * d, s.t - s.h[c] - 2f * d,
                        rnd(-30f, 30f) * d, rnd(30f, 100f) * d, rnd(1.5f, 3.5f) * d, rnd(0f, 6.28f))
                )
            }
        }
    }

    /** Один стук — снег тает, остаётся чуть-чуть. */
    fun knock() {
        for (s in all) s.goal = FloatArray(s.h.size) { s.h[it] * 0.12f }
        coverGoal = 0.05f
    }

    // ---------- физика ----------

    private fun rnd(a: Float, b: Float) = a + Random.nextFloat() * (b - a)

    private fun evaluateDay() {
        val cal = Calendar.getInstance()
        val month = cal.get(Calendar.MONTH)               // 0..11
        val inWinter = month == Calendar.DECEMBER || month == Calendar.JANUARY || month == Calendar.FEBRUARY
        val day = cal.get(Calendar.YEAR) * 400 + cal.get(Calendar.DAY_OF_YEAR)
        val rng = Random(day * 7919L + 13L)
        val lucky = rng.nextFloat() < 0.45f               // снег идёт примерно в 45% дней
        intensity = 0.4f + 0.6f * rng.nextFloat()
        snowing = if (force) true else (lucky && (!winterOnly || inWinter))
        if (force) intensity = 0.8f
    }

    private fun spawn() {
        val w = width.toFloat()
        flakes.add(Flake(rnd(0f, w) - gx * 0.4f * w, -10f * d, 0f, rnd(40f, 110f) * d, rnd(1.5f, 4f) * d, rnd(0f, 6.28f)))
    }

    private fun deposit(s: Surf, c: Int) {
        s.h[c] = min(s.cap, s.h[c] + 0.8f * d)
        for (k in intArrayOf(c - 1, c + 1)) {
            if (k in s.h.indices && s.h[c] - s.h[k] > 2.5f * d) {
                val m = (s.h[c] - s.h[k]) * 0.3f
                s.h[c] -= m; s.h[k] += m
            }
        }
    }

    private fun update(dt: Float) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        time += dt
        if (time - lastDayCheck > 30f) { evaluateDay(); lastDayCheck = time }

        // стук / встряска
        if (spikes > 0) {
            val now = System.nanoTime() / 1_000_000
            if (now - lastSpike > 420) {
                if (spikes <= 2 && firstSpikeQuiet) knock()
                else if (spikes >= 4) shakeT = 1.5f
                spikes = 0
            } else if (now - firstSpike > 1500) {
                if (spikes >= 4) shakeT = 1.5f
                spikes = 0
            }
        }
        shakeT = max(0f, shakeT - dt)

        // заметание экрана
        if (coverGoal >= 0f) {
            cover = max(coverGoal, cover - dt * 0.7f)
            if (cover <= coverGoal) coverGoal = -1f
        } else if (snowing) {
            cover = min(1f, cover + dt / (2400f / (0.5f + intensity)))   // ~30–40 минут до полного
        } else {
            cover = max(0f, cover - dt / 900f)
        }

        // таяние сугробов после стука
        for (s in all) {
            val g = s.goal ?: continue
            var done = true
            for (c in s.h.indices) {
                if (s.h[c] > g[c]) { s.h[c] = max(g[c], s.h[c] - dt * 10f * d); done = false }
            }
            if (done) s.goal = null
        }

        // осыпание при наклоне и встряхивании
        val power = max(0f, abs(gx) - 0.3f) * 2.5f + (if (shakeT > 0f) 1.2f else 0f)
        if (power > 0.05f) for (s in all) {
            repeat((power * 6f).toInt().coerceIn(1, 14)) {
                val c = Random.nextInt(s.h.size)
                if (s.h[c] > 0.5f && flakes.size < 1100) {
                    s.h[c] -= min(s.h[c], 1.2f * d)
                    flakes.add(Flake(s.l + c * step, s.t - s.h[c] - 4f * d, rnd(-25f, 25f) * d,
                        rnd(40f, 110f) * d, rnd(1.5f, 3.5f) * d, rnd(0f, 6.28f)))
                }
            }
        }

        val target = if (snowing) (50 + 130 * intensity).toInt() else 0
        var normal = 0
        var i = flakes.size - 1
        while (i >= 0) {
            val f = flakes[i]
            if (f.life >= 0f) {
                f.life -= dt; f.vy += 700f * d * dt
                f.x += f.vx * dt; f.y += f.vy * dt
                if (f.life <= 0f) flakes.removeAt(i)
                i--; continue
            }
            f.vx *= (1f - min(1f, dt * 0.8f))
            f.x += (sin((time + f.phase) * 1.4f) * 18f * d + gx * 170f * d + f.vx) * dt
            f.y += f.vy * dt

            var remove = false
            for (s in all) {
                if (f.x < s.l || f.x > s.r) continue
                val c = ((f.x - s.l) / step).toInt().coerceIn(0, s.h.size - 1)
                if (f.y >= s.t - s.h[c] && f.y <= s.t + 12f * d) { deposit(s, c); remove = true; break }
            }
            if (!remove && (f.y > h + 10f || f.x < -0.5f * w || f.x > 1.5f * w)) {
                if (normal >= target) remove = true
                else { f.y = -10f * d; f.x = rnd(0f, w) - gx * 0.4f * w; f.vx = 0f }
            }
            if (remove) flakes.removeAt(i) else normal++
            i--
        }
        normalCount = normal
        if (normal < target) repeat(2) { spawn() }
    }

    // ---------- рисование ----------

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = min((now - last) / 1e9f, 0.05f)
        last = now
        update(dt)

        for (s in all) {
            var any = false
            for (v in s.h) if (v > 0.2f) { any = true; break }
            if (!any) continue
            path.reset(); path.moveTo(s.l, s.t)
            for (k in s.h.indices) path.lineTo(min(s.l + k * step, s.r), s.t - s.h[k])
            path.lineTo(s.r, s.t); path.close()
            canvas.drawPath(path, snowPaint)
        }
        for (f in flakes) {
            flakePaint.alpha = if (f.life >= 0f) (255 * min(1f, f.life * 2f)).toInt() else 255
            canvas.drawCircle(f.x, f.y, f.r, flakePaint)
        }
        if (cover > 0.01f) {
            frostPaint.alpha = (255 * min(1f, cover * 1.15f)).toInt()
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), frostPaint)
            whitePaint.alpha = (255 * cover * cover * 0.7f).toInt()
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), whitePaint)
        }
        if (garlandOn) drawGarland(canvas)
        postInvalidateOnAnimation()
    }

    private fun drawGarland(c: Canvas) {
        val w = width.toFloat()
        val top = topInset
        val swags = max(3, (w / (110f * d)).toInt())
        val sw = w / swags
        val sag = 26f * d
        val cols = PALETTES[palette]
        var idx = 0
        for (s in 0 until swags) {
            val x1 = s * sw; val x2 = x1 + sw; val cx = (x1 + x2) / 2f; val cy = top + sag * 2f
            wire.reset(); wire.moveTo(x1, top); wire.quadTo(cx, cy, x2, top)
            c.drawPath(wire, wirePaint)
            val n = max(3, (sw / (22f * d)).toInt())
            for (i in 1 until n) {
                val u = i / n.toFloat(); val v = 1f - u
                val px = v * v * x1 + 2f * v * u * cx + u * u * x2
                val py = v * v * top + 2f * v * u * cy + u * u * top + 4f * d
                val b = when (mode) {
                    0 -> 1f
                    1 -> if (sin(time * 2.5f) > 0f) 1f else 0.2f
                    2 -> if ((idx + floor(time * 2.5f).toInt()) % 2 == 0) 1f else 0.2f
                    3 -> 0.2f + 0.8f * max(0f, sin(time * 4f - idx * 0.5f))
                    else -> 0.4f + 0.6f * (0.5f + 0.5f * sin(time * 3f + idx * 1.7f))
                }
                val col = cols[idx % cols.size]
                bulbPaint.color = col; bulbPaint.alpha = (90 * b).toInt()
                c.drawCircle(px, py, 10f * d, bulbPaint)
                bulbPaint.color = col; bulbPaint.alpha = (255 * (0.3f + 0.7f * b)).toInt()
                c.drawCircle(px, py, 3.8f * d, bulbPaint)
                idx++
            }
        }
    }

    companion object {
        const val MODES = 5   // 0 ровно, 1 мигание, 2 попеременно, 3 бегущие, 4 волна
        val PALETTES = arrayOf(
            intArrayOf(0xFFFF3B3B.toInt(), 0xFFFFD23B.toInt(), 0xFF3BFF6A.toInt(), 0xFF3BB6FF.toInt(), 0xFFD93BFF.toInt()),
            intArrayOf(0xFFFFD9A0.toInt(), 0xFFFFC870.toInt()),
            intArrayOf(0xFFFF3B3B.toInt(), 0xFF3BFF6A.toInt()),
            intArrayOf(0xFF9CD8FF.toInt(), 0xFFFFFFFF.toInt(), 0xFF5AA8FF.toInt()),
            intArrayOf(0xFFFF6FD8.toInt(), 0xFFB56BFF.toInt())
        )
    }
}
