package com.seasonal.layer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var status: TextView
    private val updaters = ArrayList<() -> Unit>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(32))
        }
        fun text(t: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); setPadding(0, 0, 0, dp(10))
        }
        col.addView(text("Сезонный слой ❄", 26f))
        status = text("", 15f, 0xFFB7D4FF.toInt())
        col.addView(status)

        fun btn(label: () -> String, onClick: () -> Unit) {
            val b = Button(this).apply {
                isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
                background = GradientDrawable().apply { setColor(0x44FFFFFF); cornerRadius = 14f * d }
                setOnClickListener {
                    onClick()
                    SeasonService.instance?.overlay?.reloadCfg()
                    refresh()
                }
            }
            updaters.add { b.text = label() }
            col.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, dp(4), 0, dp(4))
            })
        }
        fun onOff(b: Boolean) = if (b) "вкл" else "выкл"

        btn({ "1. Включить службу (спец. возможности)" }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn({ "Растопить снег сейчас" }) { SeasonService.instance?.overlay?.knock() }
        btn({ "Цвет гирлянды (по тапу на гирлянду тоже)" }) { SeasonService.instance?.overlay?.nextPalette() }
        btn({ "Режим гирлянды (долгое нажатие на неё тоже)" }) { SeasonService.instance?.overlay?.nextMode() }
        btn({ "Гирлянда: ${onOff(cfg.garlandOn)}" }) { cfg.garlandOn = !cfg.garlandOn; SeasonService.instance?.applyStrip() }
        btn({ "Нажатие на гирлянду: ${onOff(cfg.garlandTouch)}" }) { cfg.garlandTouch = !cfg.garlandTouch; SeasonService.instance?.applyStrip() }
        btn({ "Снег: ${if (cfg.forceSnow) "каждый день (проверка)" else "не каждый день"}" }) { cfg.forceSnow = !cfg.forceSnow }
        btn({ "Только зимой (дек–фев): ${onOff(cfg.winterOnly)}" }) { cfg.winterOnly = !cfg.winterOnly }
        btn({ "Чувствительность стука: ${listOf("низкая", "средняя", "высокая")[cfg.sens]}" }) { cfg.sens = (cfg.sens + 1) % 3 }

        col.addView(text(
            "\nКак пользоваться\n" +
                "• Нажми «Включить службу», найди «Сезонный слой» и включи. Если пункт серый (Android 13+): " +
                "Настройки → Приложения → Сезонный слой → ⋮ → «Разрешить ограниченные настройки».\n" +
                "• Снег идёт не каждый день. Для проверки включи «каждый день».\n" +
                "• Один резкий стук по телефону растапливает снег. Несколько толчков подряд (тряска) стряхивают сугробы.\n" +
                "• Наклон телефона сдувает снег с иконок. Если сдвинуть иконку, снег с неё падает.",
            13f, 0xFFB7D4FF.toInt()
        ))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0B1D3A.toInt()); addView(col)
        })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        status.text = if (SeasonService.instance != null) "Служба работает ✅" else "Служба выключена ⛔"
        updaters.forEach { it() }
    }
}
