package com.seasonal.layer

import android.content.Context

class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences("seasonal", Context.MODE_PRIVATE)

    var palette: Int
        get() = p.getInt("pal", 0)
        set(v) = p.edit().putInt("pal", v).apply()
    var mode: Int
        get() = p.getInt("mode", 0)
        set(v) = p.edit().putInt("mode", v).apply()
    var forceSnow: Boolean            // true = снег идёт каждый день (для проверки)
        get() = p.getBoolean("force", false)
        set(v) = p.edit().putBoolean("force", v).apply()
    var winterOnly: Boolean           // true = только декабрь–февраль
        get() = p.getBoolean("winter", false)
        set(v) = p.edit().putBoolean("winter", v).apply()
    var garlandOn: Boolean
        get() = p.getBoolean("gon", true)
        set(v) = p.edit().putBoolean("gon", v).apply()
    var garlandTouch: Boolean         // нажатие на гирлянду
        get() = p.getBoolean("gtouch", true)
        set(v) = p.edit().putBoolean("gtouch", v).apply()
    var sens: Int                     // чувствительность стука: 0 низкая, 1 средняя, 2 высокая
        get() = p.getInt("sens", 1)
        set(v) = p.edit().putInt("sens", v).apply()
}
