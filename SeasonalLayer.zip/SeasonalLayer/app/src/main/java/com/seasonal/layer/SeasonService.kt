package com.seasonal.layer

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

class SeasonService : AccessibilityService() {

    companion object { var instance: SeasonService? = null }

    lateinit var cfg: Cfg
    var overlay: SnowOverlayView? = null
    private var strip: View? = null
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var pending = false
    private val refresh = Runnable { pending = false; collect() }

    private val d get() = resources.displayMetrics.density
    private val statusH: Int get() {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else (24 * d).toInt()
    }

    override fun onServiceConnected() {
        instance = this
        cfg = Cfg(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val ov = SnowOverlayView(this, cfg)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(ov, lp)
        overlay = ov
        applyStrip()
        scheduleRefresh()
    }

    /** Узкая полоска под строкой состояния: единственное место, которое ловит касания. */
    fun applyStrip() {
        val want = cfg.garlandTouch && cfg.garlandOn
        val cur = strip
        if (!want && cur != null) { wm.removeView(cur); strip = null }
        if (want && cur == null) {
            val v = object : View(this) {
                val gd = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
                    override fun onDown(e: MotionEvent) = true
                    override fun onSingleTapUp(e: MotionEvent): Boolean { overlay?.nextPalette(); return true }
                    override fun onLongPress(e: MotionEvent) { overlay?.nextMode() }
                })
                override fun onTouchEvent(e: MotionEvent) = gd.onTouchEvent(e)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, (36 * d).toInt(),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP
            lp.y = statusH
            wm.addView(v, lp)
            strip = v
        }
    }

    private fun scheduleRefresh() {
        if (!pending) { pending = true; handler.postDelayed(refresh, 250) }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.packageName == packageName) return
        scheduleRefresh()
    }

    override fun onInterrupt() {}

    /** Собирает «поверхности» — иконки, кнопки, карточки активного окна. */
    private fun collect() {
        val root = rootInActiveWindow ?: return
        val dm = resources.displayMetrics
        val minS = (28 * d).toInt()
        val maxW = (dm.widthPixels * 0.7f).toInt()
        val maxH = (260 * d).toInt()
        val sh = statusH
        val out = ArrayList<Rect>()
        var visited = 0

        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (visited++ > 700 || depth > 14 || out.size >= 60) return
            val r = Rect(); n.getBoundsInScreen(r)
            if (n.isVisibleToUser && r.width() in minS..maxW && r.height() in minS..maxH && r.top > sh &&
                (n.isClickable || n.isLongClickable || n.contentDescription != null)
            ) {
                val dup = out.any {
                    abs(it.top - r.top) < 6 * d &&
                        minOf(it.right, r.right) - maxOf(it.left, r.left) > 0.5f * minOf(it.width(), r.width())
                }
                if (!dup) out.add(r)
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c, depth + 1)
                @Suppress("DEPRECATION") c.recycle()
            }
        }
        walk(root, 0)
        @Suppress("DEPRECATION") root.recycle()
        overlay?.setRects(out)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        handler.removeCallbacks(refresh)
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        strip?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null; strip = null; instance = null
        return super.onUnbind(intent)
    }
}
